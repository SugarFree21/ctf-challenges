# run admin bot in the background
node /ctf/admin_bot.js &

# run Flask server
python3 /ctf/server.py